using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class LavelQuit : MonoBehaviour
{

    public void QuitApp()
    {
        Application.Quit();
    }
}
