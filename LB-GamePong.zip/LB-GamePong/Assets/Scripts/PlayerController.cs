using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControls : MonoBehaviour
{
   private Rigidbody2D rb2d;

   public KeyCode moveUp;
   public KeyCode moveDown;

   public float speed = 10f;
   public float boundY = 2.5f;

   private Vector2 _direction;

   void Start()
   {
       rb2d = GetComponent<Rigidbody2D>();
   }

   private void Movement()
   {
       if (Input.GetKey(moveUp)) _direction = Vector2.up;
       else if (Input.GetKey(moveDown)) _direction = Vector2.down;
       else _direction = Vector2.zero;

       var vel = rb2d.velocity;
       vel.y = _direction.y * speed;
       rb2d.velocity = vel;
   }

   private void FixedUpdate()
   {
       if (_direction.sqrMagnitude != 0)
       {
           rb2d.AddForce(_direction * this.speed);
       }
   }

   void Update()
   {
       Movement();
   }
}